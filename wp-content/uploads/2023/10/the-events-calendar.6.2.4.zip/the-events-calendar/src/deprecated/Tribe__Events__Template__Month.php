<?php

_deprecated_file( __FILE__, '6.0.0' );

/**
 * Month view template class
 *
 * @deprecated 6.0.0
 */
class Tribe__Events__Template__Month extends Tribe__Events__Template_Factory {

	/**
	 * @deprecated 6.0.0
	 */
	const PREVIOUS_MONTH = - 1;

	/**
	 * @deprecated 6.0.0
	 */
	const CURRENT_MONTH = 0;

	/**
	 * @deprecated 6.0.0
	 */
	const NEXT_MONTH = 1;

	/**
	 * @deprecated 6.0.0
	 */
	const AJAX_HOOK = 'tribe_calendar';

	/**
	 * @deprecated 6.0.0
	 */
	public $view_path = 'month/content';

	/**
	 * @deprecated 6.0.0
	 */
	public function __construct( $args = [] ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function get_events_in_month_ids() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function json_ld_markup() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function set_notices() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function calculate_first_cell_date( $month, $start_of_week = null ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function calculate_final_cell_date( $month, $start_of_week = null ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function have_days() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function the_day() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function rewind_days() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function get_current_day() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function day_classes() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public static function get_current_week() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function event_classes( $classes = '' ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function ajax_response() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function has_events() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function has_events_filtered() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

}
