<?php

_deprecated_file( __FILE__, '6.0.0' );

/**
 * @deprecated 6.0.0
 */
class Tribe__Events__Bar {
	/**
	 * @deprecated 6.0.0
	 */
	public function hook() {

	}

	/**
	 * @deprecated 6.0.0
	 */
	public function should_show() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function body_class( $classes ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function disabled_bar_before( $before ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function disabled_bar_after( $after ) {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 6.0.0
	 */
	public function load_script() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}

	/**
	 * @deprecated 4.6.21
	 */
	public static function instance() {
		_deprecated_function( __METHOD__, '6.0.0' );
	}
}