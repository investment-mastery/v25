export { default as Virtual } from './virtual.svg';
