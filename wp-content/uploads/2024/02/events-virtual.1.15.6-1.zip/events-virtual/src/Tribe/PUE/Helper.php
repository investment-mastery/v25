<?php

namespace Tribe\Events\Virtual\PUE;

class Helper {

	/**
	 * @var string Helper data
	 */
	const DATA = 'b69ac77c4bc543950377524793dcadcaa8c3dd6d';

}
